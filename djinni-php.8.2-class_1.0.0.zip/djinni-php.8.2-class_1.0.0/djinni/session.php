<?php

namespace djinni;

class session{

}