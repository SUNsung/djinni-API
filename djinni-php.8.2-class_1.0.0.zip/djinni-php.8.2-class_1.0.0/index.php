<?php
//перевірка на версію php
if(floatval(mb_substr(phpversion(), 0, 3)) < 8.2){
    echo json_encode(["code" => 500, "msg" => "Invalid php version [".phpversion()."]. Requires 8.2 or higher."]);
    exit();
}

// Встановлення часового поясу Djinni
date_default_timezone_set('Europe/Kiev');

//Підключення класу
require_once __DIR__."/djinni/Start.php";


$DJ = new \djinni\Start();
$DJ->start_search(pages: 2)
    ->add_specialization("PHP")
    ->add_english("no_english")->add_english("basic")->add_english("pre")
    ->add_salaryFrom("2500")
    ->add_employment("remote");


echo json_encode($DJ->load_jobsBySearch());